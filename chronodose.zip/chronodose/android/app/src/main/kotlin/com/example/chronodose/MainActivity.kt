package com.example.chronodose

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
