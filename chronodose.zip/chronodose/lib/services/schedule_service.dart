import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import '../models/medication_log.dart';
import '../models/schedule.dart';

class ScheduleService {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  
  // Get all schedules
  Future<List<Schedule>> getSchedules() async {
    try {
      final snapshot = await _database.child('schedules').orderByChild('hour').get();
      
      if (snapshot.exists) {
        final schedules = <Schedule>[];
        final data = snapshot.value as Map<dynamic, dynamic>;
        
        data.forEach((key, value) {
          final scheduleData = Map<String, dynamic>.from(value as Map);
          scheduleData['id'] = key;
          schedules.add(Schedule.fromJson(scheduleData));
        });
        
        // Sort schedules by hour and then minute
        schedules.sort((a, b) {
          final aHour = _convertTo24Hour(a.time);
          final bHour = _convertTo24Hour(b.time);
          return compareTime(aHour, a.time.minute, bHour, b.time.minute);
        });
        
        return schedules;
      }
      
      return [];
    } catch (e) {
      print('Error getting schedules: $e');
      return [];
    }
  }

  Schedule? getNextDose(List<Schedule> schedules) {
    if (schedules.isEmpty) return null;
    
    // Get current time
    final now = DateTime.now();
    final currentHour = now.hour;
    final currentMinute = now.minute;
    
    // Sort schedules by time
    final sortedSchedules = List<Schedule>.from(schedules)
      ..sort((a, b) {
        final aHour = _convertTo24Hour(a.time);
        final bHour = _convertTo24Hour(b.time);
        return compareTime(aHour, a.time.minute, bHour, b.time.minute);
      });
    
    // Find next dose
    for (var schedule in sortedSchedules) {
      final scheduleHour = _convertTo24Hour(schedule.time);
      
      // Check if this schedule is after current time
      if (_isTimeAfterNow(scheduleHour, schedule.time.minute, currentHour, currentMinute)) {
        return schedule;
      }
    }
    
    // If no schedule is found after current time, return the first schedule of the day
    return sortedSchedules.first;
  }

  // Helper method to convert time to 24-hour format
  int _convertTo24Hour(TimeOfDay time) {
    int hour = time.hour;
    if (time.period == DayPeriod.pm && hour != 12) {
      hour += 12;
    }
    if (time.period == DayPeriod.am && hour == 12) {
      hour = 0;
    }
    return hour;
  }

  // Compare two times for sorting
  int compareTime(int aHour, int aMinute, int bHour, int bMinute) {
    if (aHour != bHour) return aHour.compareTo(bHour);
    return aMinute.compareTo(bMinute);
  }

  // Check if a given time is after the current time
  bool _isTimeAfterNow(int scheduleHour, int scheduleMinute, int currentHour, int currentMinute) {
    if (scheduleHour > currentHour) return true;
    if (scheduleHour == currentHour && scheduleMinute > currentMinute) return true;
    return false;
  }

  Future<Schedule?> addSchedule(Schedule schedule) async {
    try {
      // Create a map from the schedule but exclude id explicitly
      final scheduleData = {
        'hour': schedule.time.hour,
        'minute': schedule.time.minute,
        'medicines': schedule.medicines,
        'created_at': ServerValue.timestamp,
      };
      
      final newScheduleRef = _database.child('schedules').push();
      await newScheduleRef.set(scheduleData);
      
      // Get the new schedule data to return
      final snapshot = await newScheduleRef.get();
      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        data['id'] = newScheduleRef.key;
        return Schedule.fromJson(data);
      }
      
      return null;
    } catch (e) {
      print('Error adding schedule (${e.runtimeType}): $e');
      return null;
    }
  }

  Future<bool> updateSchedule(Schedule schedule) async {
    try {
      if (schedule.id == null) return false;
      
      final scheduleData = {
        'hour': schedule.time.hour,
        'minute': schedule.time.minute,
        'medicines': schedule.medicines,
        'updated_at': ServerValue.timestamp,
      };
      
      await _database.child('schedules/${schedule.id}').update(scheduleData);
      return true;
    } catch (e) {
      print('Error updating schedule: $e');
      return false;
    }
  }

  Future<bool> deleteSchedule(String id) async {
    try {
      await _database.child('schedules/$id').remove();
      return true;
    } catch (e) {
      print('Error deleting schedule: $e');
      return false;
    }
  }

  Future<DateTime?> saveRefillDate(DateTime refillDate) async {
   print('Saving refill date: $refillDate');
   try {
     // implementation of saveRefillDate method
   } catch (e) {
     print('Error saving refill date: $e');
   }
   return null;
 }

  Future<DateTime?> getRefillDate() async {
    print('Getting refill date');
    try {
      // implementation of getRefillDate method
    } catch (e) {
      print('Error getting refill date: $e');
    }
    return null;
  }
  Future<bool> markScheduleAsTaken(String scheduleId, DateTime timestamp) async {
    try {
      // First get the schedule details
      final scheduleSnapshot = await _database.child('schedules/$scheduleId').get();
      
      if (scheduleSnapshot.exists) {
        final scheduleData = scheduleSnapshot.value as Map<dynamic, dynamic>;
        
        // Then create a log entry
        final logData = {
          'schedule_id': scheduleId,
          'timestamp': timestamp.toIso8601String(),
          'medicines': scheduleData['medicines'],
          'taken_at': ServerValue.timestamp,
        };
        
        await _database.child('medication_logs').push().set(logData);
        return true;
      }
      
      return false;
    } catch (e) {
      print('Error marking schedule as taken: $e');
      return false;
    }
  }
  
  Future<List<MedicationLog>> getMedicationLogs({int limit = 50}) async {
    try {
      final snapshot = await _database
          .child('medication_logs')
          .orderByChild('taken_at')
          .limitToLast(limit)
          .get();
      
      if (snapshot.exists) {
        final logs = <MedicationLog>[];
        final data = snapshot.value as Map<dynamic, dynamic>;
        
        data.forEach((key, value) {
          final logData = Map<String, dynamic>.from(value as Map);
          logData['id'] = key;
          logs.add(MedicationLog.fromJson(logData));
        });
        
        // Sort logs by timestamp in descending order
        logs.sort((a, b) => b.timestamp.compareTo(a.timestamp));
        return logs;
      }
      
      return [];
    } catch (e) {
      print('Error getting medication logs: $e');
      return [];
    }
  }
  
  Future<List<MedicationLog>> getMedicationLogsForDateRange(DateTime start, DateTime end) async {
    try {
      // Convert dates to milliseconds since epoch for comparison
      final startEpoch = start.millisecondsSinceEpoch;
      final endEpoch = end.millisecondsSinceEpoch;
      
      final snapshot = await _database
          .child('medication_logs')
          .orderByChild('taken_at')
          .get();
      
      if (snapshot.exists) {
        final logs = <MedicationLog>[];
        final data = snapshot.value as Map<dynamic, dynamic>;
        
        data.forEach((key, value) {
          final logData = Map<String, dynamic>.from(value as Map);
          logData['id'] = key;
          
          final logTimestamp = DateTime.parse(logData['timestamp']).millisecondsSinceEpoch;
          
          // Filter logs within the date range
          if (logTimestamp >= startEpoch && logTimestamp <= endEpoch) {
            logs.add(MedicationLog.fromJson(logData));
          }
        });
        
        // Sort logs by timestamp in descending order
        logs.sort((a, b) => b.timestamp.compareTo(a.timestamp));
        return logs;
      }
      
      return [];
    } catch (e) {
      print('Error getting medication logs for date range: $e');
      return [];
    }
  }

  Future<Map<String, double>> getWeeklyAdherenceRates() async {
    Map<String, double> weeklyRates = {
      'Monday': 0.0,
      'Tuesday': 0.0,
      'Wednesday': 0.0,
      'Thursday': 0.0,
      'Friday': 0.0,
      'Saturday': 0.0,
      'Sunday': 0.0,
    };
    
    try {
      // Get current date
      final now = DateTime.now();
      
      // Calculate the start of the week (Sunday)
      final startOfWeek = now.subtract(Duration(days: now.weekday % 7));
      final startDate = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
      
      // Calculate the end of the week (Saturday)
      final endDate = startDate.add(const Duration(days: 6, hours: 23, minutes: 59, seconds: 59));
      
      // Get all schedules
      final schedules = await getSchedules();
      if (schedules.isEmpty) return weeklyRates;
      
      // Get medication logs for the week
      final logs = await getMedicationLogsForDateRange(startDate, endDate);
      
      // Calculate daily adherence
      for (int i = 0; i <= 6; i++) {
        final currentDate = startDate.add(Duration(days: i));
        final dayName = _getDayName(currentDate.weekday);
        
        // Calculate the number of scheduled doses for this day
        int scheduledDoses = schedules.length;
        
        // Count the number of doses taken on this day
        int dosesTaken = 0;
        double adherencePoints = 0.0;
        
        // For each schedule, check if there's a matching log entry for this day
        for (final schedule in schedules) {
          // Create a DateTime for the scheduled time on this day
          final scheduledTime = DateTime(
            currentDate.year,
            currentDate.month,
            currentDate.day,
            schedule.time.hour,
            schedule.time.minute,
          );
          
          // Find logs that are for this schedule on this day
          final matchingLogs = logs.where((log) {
            final logDate = log.timestamp;
            return log.scheduleId == schedule.id &&
                   logDate.year == currentDate.year &&
                   logDate.month == currentDate.month &&
                   logDate.day == currentDate.day;
          }).toList();
          
          if (matchingLogs.isNotEmpty) {
            dosesTaken++;
            
            // Find the log closest to the scheduled time
            MedicationLog closestLog = matchingLogs.first;
            int minDifference = _getTimeDifferenceInMinutes(scheduledTime, closestLog.timestamp);
            
            for (var log in matchingLogs) {
              int diff = _getTimeDifferenceInMinutes(scheduledTime, log.timestamp);
              if (diff < minDifference) {
                minDifference = diff;
                closestLog = log;
              }
            }
            
            // Calculate adherence points based on how close to scheduled time
            if (minDifference <= 15) {
              adherencePoints += 1.0;
            } else if (minDifference <= 30) {
              adherencePoints += 0.8;
            } else if (minDifference <= 60) {
              adherencePoints += 0.5;
            } else {
              adherencePoints += 0.3;
            }
          }
        }
        
        // Calculate the adherence rate
        if (scheduledDoses > 0) {
          weeklyRates[dayName] = adherencePoints / scheduledDoses;
        }
        
        // For days in the future (that haven't happened yet), set to 0
        if (currentDate.isAfter(now)) {
          weeklyRates[dayName] = 0;
        }
      }
    } catch (e) {
      print('Error calculating weekly adherence rates: $e');
    }
    
    return weeklyRates;
  }
  
  // Helper method to get time difference in minutes
  int _getTimeDifferenceInMinutes(DateTime scheduled, DateTime actual) {
    return scheduled.difference(actual).inMinutes.abs();
  }
  
  // Helper method to convert weekday int to name
  String _getDayName(int weekday) {
    switch (weekday) {
      case 1: return 'Monday';
      case 2: return 'Tuesday';
      case 3: return 'Wednesday';
      case 4: return 'Thursday';
      case 5: return 'Friday';
      case 6: return 'Saturday';
      case 7: return 'Sunday';
      default: return 'Unknown';
    }
  }
}