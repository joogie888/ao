import 'dart:async';
import 'package:chronodose/services/firebase_dispenser_service.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

class MedicationNotificationService {
  static final MedicationNotificationService _instance = MedicationNotificationService._internal();
  final FirebaseDispenserService _dispenserService = FirebaseDispenserService();
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  
  // Notification channels
  static const String CHANNEL_ID = 'medication_alerts';
  static const String CHANNEL_NAME = 'Medication Alerts';
  static const String CHANNEL_DESC = 'Notifications for medication schedules';
  
  // Notification types
  static const int NOTIFICATION_SCHEDULE = 1;
  static const int NOTIFICATION_DISPENSED = 2;
  static const int NOTIFICATION_REMINDER = 3;
  
  factory MedicationNotificationService() {
    return _instance;
  }
  
  MedicationNotificationService._internal();
  
  // Initialize notifications
  Future<void> initialize() async {
    // Initialize timezone data for scheduled notifications
    tz_data.initializeTimeZones();
    
    // Initialize local notifications
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );
    
    await _flutterLocalNotificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );
    
    // Set up the notification channels
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      CHANNEL_ID,
      CHANNEL_NAME,
      description: CHANNEL_DESC,
      importance: Importance.high,
    );
    
    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    
    // Request permissions for iOS
    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
    
    // Set up FCM (Firebase Cloud Messaging)
    await _setupFirebaseMessaging();
    
    // Set up listeners for dispenser events
    _setupDispenserEventListeners();
  }
  
  // Handle notification taps
  void _onNotificationTapped(NotificationResponse response) {
    // Parse the payload to get relevant data
    final String? payload = response.payload;
    if (payload != null) {
  
      // Navigate to appropriate screen based on payload
      // This would be implemented by the app's navigation system
      print('Notification tapped with payload: $payload');
    }
  }
  
  // Set up Firebase Cloud Messaging
  Future<void> _setupFirebaseMessaging() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    
    // Request permission
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    
    print('User granted permission: ${settings.authorizationStatus}');
    
    // Get the token
    String? token = await messaging.getToken();
    if (token != null) {
      print('FCM Token: $token');
      // Store token in Firebase for server-side messaging
      await _database.child('users/tokens').push().set(token);
    }
    
    // Handle background messages
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    
    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Got a message whilst in the foreground!');
      print('Message data: ${message.data}');
      
      if (message.notification != null) {
        print('Message also contained a notification: ${message.notification}');
        
        // Show the notification
        _showNotification(
          title: message.notification!.title ?? 'Medication Alert',
          body: message.notification!.body ?? '',
          payload: message.data.toString(),
        );
      }
    });
  }
  
  // Background message handler
  static Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    print('Handling a background message: ${message.messageId}');
    // This handler needs to be registered in main.dart before runApp()
  }
  
  // Set up listeners for dispenser events
  void _setupDispenserEventListeners() {
    // Listen for status changes from the dispenser
    _dispenserService.setDispenserEventListener(_onDispenserEvent);
    
    // Also set up a direct Firebase listener for immediate response
    _database.child('dispenser/status').onValue.listen((event) {
      if (event.snapshot.exists) {
        final Map<dynamic, dynamic> status = event.snapshot.value as Map<dynamic, dynamic>;
        
        if (status['status'] == 'ready') {
          // Medication is ready to be taken
          _handleMedicationReady(status);
        }
      }
    });
  }
  
  // Handle dispenser events
  void _onDispenserEvent(String eventType, Map<String, dynamic>? data) {
    print('Dispenser event: $eventType');
    
    switch (eventType) {
      case FirebaseDispenserService.EVENT_STATUS_CHANGE:
        if (data != null && data['status'] == 'ready') {
          _handleMedicationReady(data);
        }
        break;
      case FirebaseDispenserService.EVENT_DEVICE_ONLINE:
        _showNotification(
          title: 'Dispenser Connected',
          body: 'Your medication dispenser is now online',
        );
        break;
      case FirebaseDispenserService.EVENT_DEVICE_OFFLINE:
        _showNotification(
          title: 'Dispenser Disconnected',
          body: 'Your medication dispenser is offline. Please check the device.',
          importance: Importance.high,
        );
        break;
    }
  }
  
  // Handle when medication is ready
  void _handleMedicationReady(Map<dynamic, dynamic> data) {
    String medicationName = 'medication';
    String scheduleId = data['scheduleId'] ?? '';
    
    // Try to get the medication name if scheduleId is available
    if (scheduleId.isNotEmpty) {
      _getScheduleDetails(scheduleId).then((details) {
        if (details != null && details.containsKey('medicines')) {
          medicationName = details['medicines'];
        }
        
        _showMedicationReadyNotification(medicationName, scheduleId);
      });
    } else {
      _showMedicationReadyNotification(medicationName, scheduleId);
    }
  }
  
  // Get schedule details from Firebase
  Future<Map<String, dynamic>?> _getScheduleDetails(String scheduleId) async {
    try {
      final snapshot = await _database.child('schedules/$scheduleId').get();
      if (snapshot.exists) {
        return Map<String, dynamic>.from(snapshot.value as Map);
      }
      return null;
    } catch (e) {
      print('Error getting schedule details: $e');
      return null;
    }
  }
  
  // Show notification for medication ready
  void _showMedicationReadyNotification(String medicationName, String scheduleId) {
    _showNotification(
      id: NOTIFICATION_DISPENSED,
      title: 'Time to take your medication!',
      body: 'Your $medicationName has been dispensed and is ready to be taken.',
      importance: Importance.high,
      payload: 'schedule:$scheduleId',
      ongoing: true, // Make it persistent until addressed
    );
  }
  
  // Show a medication reminder notification
  Future<void> scheduleReminderNotification(
    int scheduleId,
    String medicineName,
    DateTime scheduledTime,
    {int reminderMinutesBefore = 5}
  ) async {
    final reminderTime = scheduledTime.subtract(Duration(minutes: reminderMinutesBefore));
    
    // Only schedule if it's in the future
    if (reminderTime.isAfter(DateTime.now())) {
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        scheduleId, 
        'Medication Reminder',
        'Time to take $medicineName in $reminderMinutesBefore minutes',
        tz.TZDateTime.from(reminderTime, tz.local),
        NotificationDetails(
          android: AndroidNotificationDetails(
            CHANNEL_ID,
            CHANNEL_NAME,
            channelDescription: CHANNEL_DESC,
            importance: Importance.high,
            priority: Priority.high,
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: 'reminder:$scheduleId',
      );
      
      print('Reminder scheduled for $medicineName at $reminderTime');
    }
  }
  
  // Show notification
  Future<void> _showNotification({
    int id = 0,
    required String title,
    required String body,
    String? payload,
    Importance importance = Importance.defaultImportance,
    bool ongoing = false,
  }) async {
    await _flutterLocalNotificationsPlugin.show(
      id,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          CHANNEL_ID,
          CHANNEL_NAME,
          channelDescription: CHANNEL_DESC,
          importance: importance,
          priority: Priority.high,
          ongoing: ongoing, // For persistent notifications
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      payload: payload,
    );
  }
  
  // Clear a specific notification
  Future<void> clearNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }
  
  // Clear all notifications
  Future<void> clearAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }
  
  // Cleanup resources
  void dispose() {
    _dispenserService.removeDispenserEventListener();
  }
}