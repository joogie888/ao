import 'dart:async';
import 'package:firebase_database/firebase_database.dart';

class FirebaseDispenserService {
  static final FirebaseDispenserService _instance = FirebaseDispenserService._internal();
  final List<Function(String, Map<String, dynamic>?)> _eventCallbacks = [];

  // Database references
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  final DatabaseReference _statusRef;
  final DatabaseReference _infoRef;
  final DatabaseReference _commandRef;
  final DatabaseReference _responseRef;
  final DatabaseReference _schedulesRef;

  bool get supportsPing => true;
  
  // Factory constructor to return the singleton instance
  factory FirebaseDispenserService() {
    return _instance;
  }

  // Constructor initializes references
  FirebaseDispenserService._internal() :
    _statusRef = FirebaseDatabase.instance.ref().child('dispenser/status'),
    _infoRef = FirebaseDatabase.instance.ref().child('dispenser/info'),
    _commandRef = FirebaseDatabase.instance.ref().child('dispenser/command'),
    _responseRef = FirebaseDatabase.instance.ref().child('dispenser/response'),
    _schedulesRef = FirebaseDatabase.instance.ref().child('schedules');
  
  // Event types for the dispenser
  static const String EVENT_DEVICE_ONLINE = 'DEVICE_ONLINE';
  static const String EVENT_DEVICE_OFFLINE = 'DEVICE_OFFLINE';
  static const String EVENT_INFO_UPDATE = 'INFO_UPDATE';
  static const String EVENT_STATUS_CHANGE = 'STATUS_CHANGE';
  static const String EVENT_MEDICATION_READY = 'MEDICATION_READY';
  static const String EVENT_MEDICATION_TAKEN = 'MEDICATION_TAKEN';
  static const String EVENT_ERROR = 'ERROR';
  
  // Stream subscriptions
  StreamSubscription<DatabaseEvent>? _infoSubscription;
  StreamSubscription<DatabaseEvent>? _statusSubscription;
  StreamSubscription<DatabaseEvent>? _connectionSubscription;
  
  bool _connected = false;
  DateTime? _lastConnectionTime;
  DateTime? _lastDeviceHeartbeat;
  Timer? _connectionWatchdog;

  bool get isConnected => _connected;
  DateTime? get lastConnectionTime => _lastConnectionTime;
  DateTime? get lastDeviceHeartbeat => _lastDeviceHeartbeat;
  
  // Set up the event listener
  void setDispenserEventListener(Function(String, Map<String, dynamic>?) callback) {
    // Add the callback if it's not already in the list
    if (!_eventCallbacks.contains(callback)) {
      _eventCallbacks.add(callback);
    }
    
    // Set up subscriptions if they don't exist yet
    _setupInfoSubscription();
    _setupStatusSubscription();
    _setupConnectionWatchdog();
  }

  // Notify all registered listeners
  void _notifyListeners(String eventType, Map<String, dynamic>? data) {
    for (var callback in List.from(_eventCallbacks)) {
      try {
        callback(eventType, data);
      } catch (e) {
        print("Error notifying listener: $e");
      }
    }
  }

  // Setup info subscription
  void _setupInfoSubscription() {
    // Only set up if not already subscribed
    if (_infoSubscription == null) {
      _infoSubscription = _infoRef.onValue.listen((event) {
        if (event.snapshot.exists) {
          final Map<Object?, Object?> rawData = event.snapshot.value as Map<Object?, Object?>;
          final Map<String, dynamic> data = _convertToStringMap(rawData);
          
          // Update device heartbeat time
          if (data.containsKey('lastSeen')) {
            _lastDeviceHeartbeat = DateTime.fromMillisecondsSinceEpoch(
              (data['lastSeen'] as int) * 1000
            );
          }
          
          // Check connection state
          bool wasConnected = _connected;
          _connected = data.containsKey('status') && data['status'] == 'online';
          
          // Emit connection state change events
          if (!wasConnected && _connected) {
            _notifyListeners(EVENT_DEVICE_ONLINE, data);
          } else if (wasConnected && !_connected) {
            _notifyListeners(EVENT_DEVICE_OFFLINE, data);
          }
          
          _notifyListeners(EVENT_INFO_UPDATE, data);
        } else {
          _connected = false;
          _notifyListeners(EVENT_INFO_UPDATE, null);
        }
      });
    }
  }

  // Set up status subscription
  void _setupStatusSubscription() {
    // Only set up if not already subscribed
    if (_statusSubscription == null) {
      _statusSubscription = _statusRef.onValue.listen((event) {
        if (event.snapshot.exists) {
          final Map<Object?, Object?> rawData = event.snapshot.value as Map<Object?, Object?>;
          final Map<String, dynamic> data = _convertToStringMap(rawData);
          
          // Check for medication ready status
          if (data.containsKey('status')) {
            String status = data['status'];
            
            if (status == 'ready') {
              _notifyListeners(EVENT_MEDICATION_READY, data);
            } else if (status == 'taken') {
              _notifyListeners(EVENT_MEDICATION_TAKEN, data);
            }
          }
          
          _notifyListeners(EVENT_STATUS_CHANGE, data);
        } else {
          _notifyListeners(EVENT_STATUS_CHANGE, null);
        }
      });
    }
  }

  // Setup a connection watchdog to detect if device goes offline
  void _setupConnectionWatchdog() {
    // Cancel existing timer if it exists
    _connectionWatchdog?.cancel();
    
    // Check device connection state every 30 seconds
    _connectionWatchdog = Timer.periodic(const Duration(seconds: 30), (timer) {
      // If we haven't received a heartbeat in 2 minutes, consider the device offline
      if (_lastDeviceHeartbeat != null) {
        final timeSinceLastHeartbeat = DateTime.now().difference(_lastDeviceHeartbeat!);
        
        if (timeSinceLastHeartbeat.inMinutes >= 2 && _connected) {
          _connected = false;
          _notifyListeners(EVENT_DEVICE_OFFLINE, {
            'reason': 'No heartbeat received for ${timeSinceLastHeartbeat.inMinutes} minutes',
            'lastHeartbeat': _lastDeviceHeartbeat!.millisecondsSinceEpoch ~/ 1000
          });
        }
      }
    });
  }

  // Remove a specific event listener
  void removeSpecificEventListener(Function(String, Map<String, dynamic>?) callback) {
    _eventCallbacks.remove(callback);
    
    // If no listeners left, cancel subscriptions
    if (_eventCallbacks.isEmpty) {
      removeDispenserEventListener();
    }
  }

  // Remove all event listeners
  void removeDispenserEventListener() {
    // Cancel existing subscriptions
    _infoSubscription?.cancel();
    _statusSubscription?.cancel();
    _connectionSubscription?.cancel();
    _connectionWatchdog?.cancel();
    
    // Clear the subscriptions
    _infoSubscription = null;
    _statusSubscription = null;
    _connectionSubscription = null;
    _connectionWatchdog = null;
    
    // Clear callbacks
    _eventCallbacks.clear();
  }

  // Ping the device to check if it's online
  Future<bool?> pingDevice() async {
    try {
      if (!_connected) {
        print("Cannot ping: device not connected");
        return false;
      }
      
      // Send PING command
      await _commandRef.set({
        'type': 'PING',
        'timestamp': ServerValue.timestamp,
      });
      
      // Wait for response with timeout
      final response = await _waitForCommandResponse('PING', timeout: 5);
      
      return response != null && 
             response.containsKey('status') && 
             response['status'] == 'acknowledged';
    } catch (e) {
      print("Error pinging device: $e");
      return false;
    }
  }
  
  // Test basic Firebase connectivity
  Future<bool> testConnection() async {
    try {
      final snapshot = await _database.child('.info/connected').get();
      return snapshot.exists && snapshot.value == true;
    } catch (e) {
      print("Firebase connection test failed: $e");
      return false;
    }
  }
  
  // Connect to the dispenser
  Future<bool> connectToDispenser() async {
    try {
      print("Connecting to dispenser...");
      
      // Check if dispenser info exists
      final infoSnapshot = await _infoRef.get();
      if (!infoSnapshot.exists) {
        print("Dispenser info not found in database");
        _connected = false;
        return false;
      }
      
      print("Dispenser info found");
      final Map<Object?, Object?> rawData = infoSnapshot.value as Map<Object?, Object?>;
      final Map<String, dynamic> deviceInfo = _convertToStringMap(rawData);
      
      // Check if device is online
      if (!deviceInfo.containsKey('status') || deviceInfo['status'] != 'online') {
        print("Dispenser not online. Current status: ${deviceInfo['status']}");
        _connected = false;
        return false;
      }
      
      print("Dispenser is online");
      
      // Send ping command
      print("Sending PING command");
      await _commandRef.set({
        'type': 'PING',
        'timestamp': ServerValue.timestamp,
      });
      
      // Wait for response
      final response = await _waitForCommandResponse('PING', timeout: 5);
      
      if (response != null && 
          response.containsKey('status') && 
          response['status'] == 'acknowledged') {
        print("Connection successful");
        _connected = true;
        _lastConnectionTime = DateTime.now();
        
        // Store last heartbeat time
        if (deviceInfo.containsKey('lastSeen')) {
          _lastDeviceHeartbeat = DateTime.fromMillisecondsSinceEpoch(
            (deviceInfo['lastSeen'] as int) * 1000
          );
        }
        
        return true;
      }
      
      print("Invalid response: $response");
      _connected = false;
      return false;
    } catch (e) {
      print("Error connecting to dispenser: $e");
      _connected = false;
      return false;
    }
  }
  
  // Get device information
  Future<Map<String, dynamic>?> getDeviceInfo() async {
    try {
      final snapshot = await _infoRef.get();
      if (snapshot.exists) {
        final Map<Object?, Object?> rawData = snapshot.value as Map<Object?, Object?>;
        return _convertToStringMap(rawData);
      }
      return null;
    } catch (e) {
      print("Error getting device info: $e");
      return null;
    }
  }
  
  // Manually trigger a medication dispensing
  Future<bool> triggerMedicationDispense(String scheduleId) async {
    try {
      if (!_connected) {
        print("Cannot dispense: device not connected");
        return false;
      }
      
      // Check if schedule exists
      final scheduleSnapshot = await _schedulesRef.child(scheduleId).get();
      if (!scheduleSnapshot.exists) {
        print("Schedule not found: $scheduleId");
        return false;
      }
      
      // Send command to dispense
      await _commandRef.set({
        'type': 'MANUAL_DISPENSE',
        'timestamp': ServerValue.timestamp,
        'scheduleId': scheduleId,
      });
      
      // Wait for response
      final response = await _waitForCommandResponse('MANUAL_DISPENSE', timeout: 10);
      
      return response != null && 
             response.containsKey('status') && 
             response['status'] == 'acknowledged';
    } catch (e) {
      print("Error triggering medication dispense: $e");
      return false;
    }
  }

  // Force sync time
  Future<bool> forceTimeSync(DateTime time, {int extendedTimeout = 30}) async {
    try {
      if (!_connected) {
        print("Cannot force sync time: device not connected");
        return false;
      }
      
      print("Starting force time sync with extended timeout of $extendedTimeout seconds");
      
      // Update serverTime in Firebase
      final timestamp = (time.millisecondsSinceEpoch / 1000).floor();
      await _database.child('serverTime').set(timestamp);
      
      // Send command with FORCE flag
      final commandData = {
        'type': 'FORCE_TIME_SYNC',
        'timestamp': timestamp,
        'timezone': time.timeZoneOffset.inHours,
        'force': true
      };
      
      await _commandRef.set(commandData);
      
      // Wait with extended timeout
      final response = await _waitForCommandResponse('FORCE_TIME_SYNC', timeout: extendedTimeout);
      
      if (response != null && 
          response.containsKey('status') && 
          response['status'] == 'acknowledged') {
        print('Force time sync successful: ${response['newTime']}');
        return true;
      } else {
        print('Force time sync failed or timed out after $extendedTimeout seconds');
        return false;
      }
    } catch (e) {
      print('Error in force time sync: $e');
      return false;
    }
  }

  // Send schedules to device
  Future<bool> sendSchedulesToDevice(List<dynamic> schedules) async {
    try {
      if (!_connected) {
        print("Cannot send schedules: device not connected");
        return false;
      }
      
      // Convert schedules to a format suitable for Firebase
      final List<Map<String, dynamic>> schedulesData = [];
      for (var schedule in schedules) {
        schedulesData.add({
          'id': schedule.id,
          'medicines': schedule.medicines,
          'time': '${schedule.time.hour}:${schedule.time.minute.toString().padLeft(2, '0')}',
          'isEnabled': schedule.isEnabled,
        });
      }
      
      // Send command to device
      await _commandRef.set({
        'type': 'SET_SCHEDULES',
        'timestamp': ServerValue.timestamp,
        'schedules': schedulesData,
      });
      
      // Wait for response
      final response = await _waitForCommandResponse('SET_SCHEDULES', timeout: 10);
      
      return response != null && 
             response.containsKey('status') && 
             response['status'] == 'acknowledged';
    } catch (e) {
      print("Error sending schedules to device: $e");
      return false;
    }
  }

  // Send time to device
  Future<bool> sendTimeToDevice(DateTime time) async {
    try {
      if (!_connected) {
        print("Cannot send time: device not connected");
        return false;
      }
      
      // First update serverTime in Firebase
      final timestamp = (time.millisecondsSinceEpoch / 1000).floor();
      await _database.child('serverTime').set(timestamp);
      
      // Then send a command to the device to sync time
      final commandData = {
        'type': 'SET_TIME',
        'timestamp': timestamp,
        'timezone': time.timeZoneOffset.inHours
      };
      
      await _database.child('dispenser/command').set(commandData);
      
      // Wait for response with increased timeout
      final response = await _waitForCommandResponse('SET_TIME', timeout: 15);
      
      if (response != null && 
          response.containsKey('status') && 
          response['status'] == 'acknowledged') {
        print('Time sync successful: ${response['newTime']}');
        return true;
      } else {
        // Enhanced error reporting
        if (response == null) {
          print('Time sync timed out waiting for response');
        } else {
          print('Time sync failed with response: $response');
        }
        return false;
      }
    } catch (e) {
      print('Error sending time to device: $e');
      return false;
    }
  }

  Future<Duration?> checkTimeDrift() async {
    try {
      if (!_connected) return null;
      
      final deviceInfo = await getDeviceInfo();
      if (deviceInfo == null || !deviceInfo.containsKey('lastSeen')) return null;
      
      final deviceTime = DateTime.fromMillisecondsSinceEpoch(
        (deviceInfo['lastSeen'] as int) * 1000
      );
      final now = DateTime.now();
      
      return now.difference(deviceTime);
    } catch (e) {
      print('Error checking time drift: $e');
      return null;
    }
  }
  
  // Helper method to wait for command response
  Future<Map<String, dynamic>?> _waitForCommandResponse(String expectedCommand, {int timeout = 15}) async {
    final completer = Completer<Map<String, dynamic>?>();
    late StreamSubscription subscription;
    
    subscription = _responseRef.onValue.listen((event) {
      if (event.snapshot.exists) {
        final Map<Object?, Object?> rawData = event.snapshot.value as Map<Object?, Object?>;
        final Map<String, dynamic> response = _convertToStringMap(rawData);
        
        // Check if this is the response we're waiting for
        if (response.containsKey('lastCommand') && 
            response['lastCommand'] == expectedCommand) {
          if (!completer.isCompleted) {
            subscription.cancel();
            completer.complete(response);
          }
        }
      }
    });
    
    Future.delayed(Duration(seconds: timeout), () {
      if (!completer.isCompleted) {
        subscription.cancel();
        completer.complete(null);
      }
    });
    
    return completer.future;
  }
  
  // Helper method to convert Firebase response to String keys
  Map<String, dynamic> _convertToStringMap(Map<Object?, Object?> rawData) {
    final Map<String, dynamic> result = {};
    
    rawData.forEach((key, value) {
      if (key is String) {
        if (value is Map) {
          // Handle nested maps
          result[key] = _convertToStringMap(value as Map<Object?, Object?>);
        } else {
          result[key] = value;
        }
      }
    });
    
    return result;
  }
  
  // Disconnect and clean up
  void disconnect() {
    removeDispenserEventListener();
    _connected = false;
  }
}