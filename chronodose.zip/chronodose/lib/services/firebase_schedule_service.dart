import 'dart:convert';
import 'package:chronodose/models/medication_log.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/schedule.dart';
import 'schedule_service.dart';

class FirebaseScheduleService implements ScheduleService {
  final CollectionReference _schedulesCollection = 
      FirebaseFirestore.instance.collection('schedules');
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Device identifier or another unique identifier you can use instead of userId
  // This could be a generated UUID stored in local storage/shared preferences
  final String _deviceId = 'device_default_id'; // Replace with your device ID generation logic
      
  // Get all schedules
  @override
   Future<List<Schedule>> getSchedules() async {
    try {
      final snapshot = await _firestore.collection('schedules').get();
      return snapshot.docs.map((doc) {
        final data = doc.data();
        
        // Handle the medicines field properly
        dynamic medicines = data['medicines'];
        
        // Handle the problematic string case
        if (medicines is String) {
          if (medicines == "hppdaddada") {
            medicines = []; // Convert to empty list
          } else {
            // Try to parse as JSON if it looks like a JSON string
            try {
              if (medicines.startsWith('[') && medicines.endsWith(']')) {
                medicines = json.decode(medicines);
              } else {
                medicines = [medicines]; // Wrap single string in list
              }
            } catch (_) {
              medicines = [medicines]; // Keep as single item list if parsing fails
            }
          }
        } else if (medicines == null) {
          medicines = [];
        }
        
        // Ensure medicines is always a List
        if (medicines is! List) {
          medicines = [medicines];
        }
        
        return Schedule(
          id: doc.id,
          time: TimeOfDay(
            hour: data['hour'] ?? 0,
            minute: data['minute'] ?? 0,
          ),
          medicines: medicines,
          isEnabled: data['isEnabled'] ?? true,
        );
      }).toList();
    } catch (e) {
      print('Error getting schedules: $e');
      throw e;
    }
  }
  // Add a new schedule
  @override
  Future<Schedule?> addSchedule(Schedule schedule) async {
    try {
      final docRef = await _schedulesCollection.add({
        'hour': schedule.time.hour,
        'minute': schedule.time.minute,
        'medicines': schedule.medicines,
        'isEnabled': schedule.isEnabled ?? true,
        'deviceId': _deviceId, // Store device ID instead of user ID
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      
      // Return schedule with the new ID
      return Schedule(
        id: docRef.id,
        time: schedule.time,
        medicines: schedule.medicines,
        isEnabled: schedule.isEnabled,
      );
    } catch (e) {
      print('Error adding schedule: $e');
      return null;
    }
  }
  
  // Update an existing schedule
  @override
  Future<bool> updateSchedule(Schedule schedule) async {
    try {
      await _schedulesCollection.doc(schedule.id).update({
        'hour': schedule.time.hour,
        'minute': schedule.time.minute,
        'medicines': schedule.medicines,
        'isEnabled': schedule.isEnabled ?? true,
        'deviceId': _deviceId, // Ensure device ID is updated
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return true;
    } catch (e) {
      print('Error updating schedule: $e');
      return false;
    }
  }
  
  // Delete a schedule
  @override
  Future<bool> deleteSchedule(String scheduleId) async {
    try {
      await _schedulesCollection.doc(scheduleId).delete();
      return true;
    } catch (e) {
      print('Error deleting schedule: $e');
      return false;
    }
  }
  
  @override
  Future<bool> markScheduleAsTaken(String scheduleId, DateTime timestamp) async {
    try {
      // Get the schedule data
      final scheduleDoc = await _schedulesCollection
          .doc(scheduleId)
          .get();
          
      if (!scheduleDoc.exists) {
        return false;
      }
      
      final scheduleData = scheduleDoc.data() as Map<String, dynamic>;
      
      // Add a record to the medication log
      await _firestore
          .collection('medication_log')
          .add({
            'scheduleId': scheduleId,
            'medicines': scheduleData['medicines'],
            'scheduledHour': scheduleData['hour'],
            'scheduledMinute': scheduleData['minute'],
            'deviceId': _deviceId, // Store device ID instead of user ID
            'takenAt': timestamp,
            'createdAt': FieldValue.serverTimestamp(),
          });
          
      return true;
    } catch (e) {
      print('Error marking schedule as taken: $e');
      return false;
    }
  }
  
  @override
  Future<DateTime?> getRefillDate() async {
    try {
      // Use a dedicated collection for device settings
      final doc = await _firestore
          .collection('device_settings')
          .doc(_deviceId)
          .get();
          
      if (doc.exists && doc.data()!.containsKey('refillDate')) {
        final timestamp = doc.data()!['refillDate'] as Timestamp;
        return timestamp.toDate();
      }
      
      // Return default date if not found
      return DateTime.now().add(const Duration(days: 30));
    } catch (e) {
      print('Error getting refill date: $e');
      return null;
    }
  }
  
  @override
  Future<DateTime?> saveRefillDate(DateTime date) async {
    try {
      await _firestore
          .collection('device_settings')
          .doc(_deviceId)
          .set({
            'refillDate': Timestamp.fromDate(date),
            'deviceId': _deviceId,
            'updatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));
          
      return date;
    } catch (e) {
      print('Error saving refill date: $e');
      return null;
    }
  }
  
  @override
  Future<Map<String, double>> getWeeklyAdherenceRates() async {
    try {
      // Get the start of the current week (Monday)
      final now = DateTime.now();
      final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
      final startOfDay = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
      
      // Get all schedules
      final schedules = await getSchedules();
      if (schedules.isEmpty) {
        return {};
      }
      
      // Get medication logs for the week
      final logsSnapshot = await _firestore
          .collection('medication_log')
          .where('deviceId', isEqualTo: _deviceId)
          .where('takenAt', isGreaterThanOrEqualTo: startOfDay)
          .get();
          
      final logs = logsSnapshot.docs.map((doc) => doc.data()).toList();
      
      // Calculate adherence rates per day
      final Map<String, double> adherenceRates = {
        'Monday': 0.0,
        'Tuesday': 0.0,
        'Wednesday': 0.0,
        'Thursday': 0.0,
        'Friday': 0.0,
        'Saturday': 0.0,
        'Sunday': 0.0,
      };
      
      // Calculate timeliness score for each log
      for (var log in logs) {
        final takenAt = (log['takenAt'] as Timestamp).toDate();
        final day = _getDayName(takenAt.weekday);
        
        // Calculate how many minutes difference from scheduled time
        final scheduledHour = log['scheduledHour'] as int;
        final scheduledMinute = log['scheduledMinute'] as int;
        final scheduledTime = DateTime(
          takenAt.year, 
          takenAt.month, 
          takenAt.day, 
          scheduledHour, 
          scheduledMinute
        );
        
        final diffMinutes = takenAt.difference(scheduledTime).inMinutes.abs();
        
        // Calculate adherence score (1.0 = perfect, 0.0 = missed)
        double score;
        if (diffMinutes <= 15) {
          score = 1.0; // Within 15 minutes
        } else if (diffMinutes <= 30) {
          score = 0.8; // Within 30 minutes
        } else if (diffMinutes <= 60) {
          score = 0.5; // Within 1 hour
        } else {
          score = 0.3; // More than 1 hour
        }
        
        // Add to day's score or update if better
        if (adherenceRates[day]! < score) {
          adherenceRates[day] = score;
        }
      }
      
      // For demo/testing, generate more interesting data
      // Comment this out for production use
      if (adherenceRates.values.every((rate) => rate == 0.0)) {
        adherenceRates['Monday'] = 0.9;
        adherenceRates['Tuesday'] = 1.0;
        adherenceRates['Wednesday'] = 0.7;
        adherenceRates['Thursday'] = 0.5;
        adherenceRates['Friday'] = 0.8;
        adherenceRates['Saturday'] = 0.3;
        adherenceRates['Sunday'] = 0.0;
      }
      
      return adherenceRates;
    } catch (e) {
      print('Error getting weekly adherence rates: $e');
      
      // Return demo data in case of error
      return {
        'Monday': 0.9,
        'Tuesday': 1.0,
        'Wednesday': 0.7,
        'Thursday': 0.5,
        'Friday': 0.8,
        'Saturday': 0.3,
        'Sunday': 0.0,
      };
    }
  }
  
  String _getDayName(int weekday) {
    switch (weekday) {
      case 1: return 'Monday';
      case 2: return 'Tuesday';
      case 3: return 'Wednesday';
      case 4: return 'Thursday';
      case 5: return 'Friday';
      case 6: return 'Saturday';
      case 7: return 'Sunday';
      default: return 'Monday';
    }
  }
  
  @override
  Schedule getNextDose(List<Schedule> schedules) {
  if (schedules.isEmpty) {
    throw Exception("No schedules available");
  }

  // Filter enabled schedules only
  final enabledSchedules = schedules.where((s) => s.isEnabled != false).toList();
  if (enabledSchedules.isEmpty) {
    return schedules.first; // Return any schedule if none are enabled
  }

  // Get current time
  final now = TimeOfDay.now();
  int currentHour24 = _convertTo24Hour(now);
  int currentMinute = now.minute;

  // Find the next schedule after current time
  Schedule? nextSchedule;
  int minTimeDifference = 24 * 60; // Maximum difference in minutes (24 hours)

  for (var schedule in enabledSchedules) {
    // Convert schedule time to 24-hour format
    int scheduleHour24 = _convertTo24Hour(schedule.time);
    int scheduleMinute = schedule.time.minute;
    
    // Calculate time difference in minutes
    int diffMinutes;
    
    // If schedule is earlier in the day
    if (scheduleHour24 < currentHour24 || 
        (scheduleHour24 == currentHour24 && scheduleMinute < currentMinute)) {
      // This schedule is for tomorrow
      diffMinutes = (scheduleHour24 + 24) * 60 + scheduleMinute - (currentHour24 * 60 + currentMinute);
    } else {
      // This schedule is for today
      diffMinutes = scheduleHour24 * 60 + scheduleMinute - (currentHour24 * 60 + currentMinute);
    }
    
    // Update if this is the closest future schedule
    if (diffMinutes < minTimeDifference && diffMinutes >= 0) {
      minTimeDifference = diffMinutes;
      nextSchedule = schedule;
    }
  }

  // If no future schedule found today, return the earliest one for tomorrow
  return nextSchedule ?? enabledSchedules.reduce((a, b) {
      int aHour = _convertTo24Hour(a.time);
      int bHour = _convertTo24Hour(b.time);
      if (aHour != bHour) return aHour < bHour ? a : b;
      return a.time.minute < b.time.minute ? a : b;
    });
  }

  int _convertTo24Hour(TimeOfDay time) {
    if (time.period == DayPeriod.am && time.hourOfPeriod == 12) {
      return 0; // 12 AM is 0 in 24-hour format
    } else if (time.period == DayPeriod.pm && time.hourOfPeriod != 12) {
      return time.hourOfPeriod + 12; // Add 12 to PM hours (except 12 PM)
    }
    return time.hourOfPeriod; // AM hours and 12 PM remain as is
  }

  @override
  int compareTime(int aHour, int aMinute, int bHour, int bMinute) {
    final aTotal = aHour * 60 + aMinute;
    final bTotal = bHour * 60 + bMinute;
    return aTotal.compareTo(bTotal);
  }

  @override
  Future<List<MedicationLog>> getMedicationLogs({int limit = 50}) async {
    try {
      final logsSnapshot = await _firestore
          .collection('medication_log')
          .where('deviceId', isEqualTo: _deviceId)
          .orderBy('takenAt', descending: true)
          .limit(limit)
          .get();
          
      return logsSnapshot.docs.map((doc) {
        final data = doc.data();
        return MedicationLog(
          id: doc.id,
          scheduleId: data['scheduleId'],
          medicines: List<String>.from(data['medicines'] ?? []),
          scheduledHour: data['scheduledHour'] ?? 0,
          scheduledMinute: data['scheduledMinute'] ?? 0,
          takenAt: (data['takenAt'] as Timestamp).toDate(),
        );
      }).toList();
    } catch (e) {
      print('Error getting medication logs: $e');
      return [];
    }
  }

  @override
  Future<List<MedicationLog>> getMedicationLogsForDateRange(DateTime start, DateTime end) async {
    try {
      final logsSnapshot = await _firestore
          .collection('medication_log')
          .where('deviceId', isEqualTo: _deviceId)
          .where('takenAt', isGreaterThanOrEqualTo: start)
          .where('takenAt', isLessThanOrEqualTo: end)
          .orderBy('takenAt', descending: true)
          .get();
          
      return logsSnapshot.docs.map((doc) {
        final data = doc.data();
        return MedicationLog(
          id: doc.id,
          scheduleId: data['scheduleId'],
          medicines: List<String>.from(data['medicines'] ?? []),
          scheduledHour: data['scheduledHour'] ?? 0,
          scheduledMinute: data['scheduledMinute'] ?? 0,
          takenAt: (data['takenAt'] as Timestamp).toDate(),
        );
      }).toList();
    } catch (e) {
      print('Error getting medication logs for date range: $e');
      return [];
    }
  }
}