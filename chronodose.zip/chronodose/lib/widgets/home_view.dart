import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/schedule.dart';
import '../pages/home_page.dart';
import '../pages/medication_log_page.dart';
import '../pages/schedule_detail_page.dart';
import '../services/firebase_schedule_service.dart';

class HomeView extends StatefulWidget {
  final Function(Schedule, bool) onScheduleToggled;
  final bool dispenserConnected;
  final Function(BuildContext) onSelectRefillDate;
  final Function? onRefresh;
  
  const HomeView({
    Key? key,
    required this.onScheduleToggled,
    required this.dispenserConnected,
    required this.onSelectRefillDate,
    this.onRefresh,
  }) : super(key: key);

  @override
  State<HomeView> createState() => HomeViewState();
}

class HomeViewState extends State<HomeView> {
  final FirebaseScheduleService _scheduleService = FirebaseScheduleService();
  Map<String, double> weeklyAdherenceRates = {};
  bool _isLoadingAdherence = true;
  bool _hasAdherenceData = false;  // New flag to track if actual data exists
  String _selectedPeriod = 'This Week';
  final List<String> _timePeriods = ['This Week', 'Last Week', 'This Month'];
  Timer? _timer;
  Schedule? _nextDose;
  
  @override
  void initState() {
    super.initState();
    _loadWeeklyAdherenceData();
    _updateNextDose();
    HomePage.currentHomeViewState = this;
    
    // Set up timer to update the next dose every minute
    _timer = Timer.periodic(const Duration(minutes: 1), (timer) {
      _updateNextDose();
    });
  }

  @override
  void dispose() {
    if (HomePage.currentHomeViewState == this) {
      HomePage.currentHomeViewState = null;
    }
    _timer?.cancel();
    super.dispose();
  }

  @override
  void didUpdateWidget(HomeView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Force update next dose when widget updates
    _updateNextDose();
  }

  void refreshNextDose() {
    if (!mounted) return;
  
    // Immediately fetch latest schedules and update next dose
    _scheduleService.getSchedules().then((latestSchedules) {
      if (mounted) {
        setState(() {
          // Update HomePage.schedules with latest data
          HomePage.schedules = latestSchedules;
          // Calculate next dose from latest schedules
          _nextDose = _scheduleService.getNextDose(latestSchedules);
        });
      }
    });
  }

  void _updateNextDose() {
    if (!mounted) return;
    
    // Use a more reliable method to get the next dose
    _scheduleService.getSchedules().then((latestSchedules) {
      if (mounted) {
        setState(() {
          // Update HomePage.schedules with latest data
          HomePage.schedules = latestSchedules;
          // Calculate next dose from latest schedules
          _nextDose = _scheduleService.getNextDose(latestSchedules);
        });
      }
    }).catchError((e) {
      print("Error updating next dose: $e");
    });
  }

  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // When app comes to foreground, update the next dose
      _updateNextDose();
    }
  }

  Future<void> _loadWeeklyAdherenceData() async {
    setState(() {
      _isLoadingAdherence = true;
    });
    
    try {
      // Get the weekly adherence data from the service
      final weeklyData = await _scheduleService.getWeeklyAdherenceRates();
      
      // Check if there's any actual data (non-zero values)
      bool hasData = weeklyData.values.any((value) => value > 0);
      
      setState(() {
        weeklyAdherenceRates = weeklyData;
        _isLoadingAdherence = false;
        _hasAdherenceData = hasData;
      });
    } catch (e) {
      print('Error loading adherence data: $e');
      setState(() {
        _isLoadingAdherence = false;
        _hasAdherenceData = false;
      });
    }
  }

  double _calculateOverallAdherence() {
    if (weeklyAdherenceRates.isEmpty) return 0.0;
  
    double sum = weeklyAdherenceRates.values
        .where((value) => value > 0)
        .fold(0.0, (prev, curr) => prev + curr);
  
    int daysWithData = weeklyAdherenceRates.values
        .where((value) => value > 0)
        .length;
      
    return daysWithData > 0 ? sum / daysWithData : 0.0;
  }

  String _getAdherenceMessage(double rate) {
    if (rate == 0) return 'No doses taken';
    if (rate >= 0.8) return 'Excellent! Most doses taken within 15 minutes of schedule';
    if (rate >= 0.5) return 'Good. Doses taken within 30-60 minutes of schedule';
    return 'Needs improvement. Doses taken more than 60 minutes from schedule';
  }

  String _getShortAdherenceStatus(double rate) {
    if (rate >= 0.8) return "On time";
    if (rate >= 0.5) return "Slightly delayed";
    return "Significantly delayed";
  }

  Widget _buildLegendItem(Color color, String label) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade700,
          ),
        ),
      ],
    );
  }

  void _showDayDetails(BuildContext context, String day) {
    // Get the day of week as int (1-7)
    int dayOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].indexOf(day) + 1;
    
    // Calculate the date for this day
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final dayDate = startOfWeek.add(Duration(days: dayOfWeek - 1));
    
    // Navigate to a filtered view of the medication log for this day
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MedicationLogPage(filterDate: dayDate),
      ),
    );
  }

  Widget _buildDayRow(String day, double adherenceRate) {
    // Make sure adherence rate is between 0 and 1
    adherenceRate = adherenceRate.clamp(0.0, 1.0);
    
    // Determine color based on adherence rate
    Color progressColor;
    if (adherenceRate >= 0.8) {
      progressColor = Colors.green;
    } else if (adherenceRate >= 0.5) {
      progressColor = Colors.orange;
    } else {
      progressColor = Colors.red;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.grey.shade50,
      ),
      child: Row(
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: Stack(
              children: [
                Center(
                  child: SizedBox(
                    width: 50,
                    height: 50,
                    child: CircularProgressIndicator(
                      value: adherenceRate,
                      backgroundColor: Colors.grey.shade200,
                      color: progressColor,
                      strokeWidth: 8,
                    ),
                  ),
                ),
                Center(
                  child: Text(
                    '${(adherenceRate * 100).toInt()}%',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  day,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (adherenceRate > 0)
                  Text(
                    _getShortAdherenceStatus(adherenceRate),
                    style: TextStyle(
                      fontSize: 14,
                      color: progressColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
              ],
            ),
          ),
          Icon(
            Icons.chevron_right,
            color: Colors.grey.shade400,
          ),
        ],
      ),
    );
  }

  // Format the time string correctly with leading zeros for minutes
  String _formatTimeString(Schedule? schedule) {
    if (schedule == null) return 'No doses';
    
    final hour = schedule.time.hourOfPeriod;
    final minute = schedule.time.minute.toString().padLeft(2, '0');
    final period = schedule.time.period == DayPeriod.am ? 'AM' : 'PM';
    
    return '$hour:$minute $period';
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Schedules container
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    // Pass the entire schedule list instead of just the next dose
                    return ScheduleDetailPage(schedules: HomePage.schedules);
                  },
                ),
              );
            },
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.lightBlue.shade100,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    'Schedules',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Next Dose',
                          style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            _formatTimeString(_nextDose),
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(Icons.chevron_right, size: 30),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Next Refill container
          Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Refill',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade100,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.add, color: Colors.blue),
                          ),
                          const SizedBox(width: 16),
                          Text(
                            DateFormat('M/d/yy').format(HomePage.refillDate),
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      ElevatedButton(
                        onPressed: () {
                          widget.onSelectRefillDate(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          'Change',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Weekly Report container
          Container(
            width: double.infinity,
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "${_selectedPeriod}'s report",
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Row(
                      children: [
                        DropdownButton<String>(
                          value: _selectedPeriod,
                          onChanged: (String? newValue) {
                            if (newValue != null) {
                              setState(() {
                                _selectedPeriod = newValue;
                              });
                              _loadWeeklyAdherenceData();
                            }
                          },
                          items: _timePeriods.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                        const SizedBox(width: 8),
                        if (_isLoadingAdherence)
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.blue.shade300,
                            ),
                          )
                        else
                          IconButton(
                            icon: const Icon(Icons.refresh),
                            onPressed: _loadWeeklyAdherenceData,
                          ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                
                // Display different content based on data availability
                if (_isLoadingAdherence)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: CircularProgressIndicator(),
                    ),
                  )
                else if (!_hasAdherenceData)
                  // No data case
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 40),
                      child: Column(
                        children: [
                          Icon(
                            Icons.medication_outlined,
                            size: 60,
                            color: Colors.grey.shade400,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No medication history available yet',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              color: Colors.grey.shade700,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Your adherence report will appear here after \nyou start taking your medication',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  // Has data case - show adherence data
                  Column(
                    children: [
                      // Overall adherence summary
                      Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Overall Adherence: ',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.grey.shade700,
                                      ),
                                    ),
                                    Text(
                                      '${(_calculateOverallAdherence() * 100).toInt()}%',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: _calculateOverallAdherence() >= 0.8 
                                            ? Colors.green 
                                            : _calculateOverallAdherence() >= 0.5 
                                                ? Colors.orange 
                                                : Colors.red,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Container(
                                  width: 200,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4),
                                    color: Colors.grey.shade200,
                                  ),
                                  child: FractionallySizedBox(
                                    alignment: Alignment.centerLeft,
                                    widthFactor: _calculateOverallAdherence(),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(4),
                                        color: _calculateOverallAdherence() >= 0.8 
                                            ? Colors.green 
                                            : _calculateOverallAdherence() >= 0.5 
                                                ? Colors.orange 
                                                : Colors.red,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      
                      // Adherence legend
                      Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildLegendItem(Colors.green, "Within 15 min"),
                            const SizedBox(width: 16),
                            _buildLegendItem(Colors.orange, "Within 30-60 min"),
                            const SizedBox(width: 16),
                            _buildLegendItem(Colors.red, "> 60 min"),
                          ],
                        ),
                      ),
                      
                      // Daily adherence rows
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Monday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Monday'] ?? 0),
                          child: _buildDayRow('Monday', weeklyAdherenceRates['Monday'] ?? 0),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Tuesday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Tuesday'] ?? 0),
                          child: _buildDayRow('Tuesday', weeklyAdherenceRates['Tuesday'] ?? 0),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Wednesday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Wednesday'] ?? 0),
                          child: _buildDayRow('Wednesday', weeklyAdherenceRates['Wednesday'] ?? 0),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Thursday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Thursday'] ?? 0),
                          child: _buildDayRow('Thursday', weeklyAdherenceRates['Thursday'] ?? 0),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Friday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Friday'] ?? 0),
                          child: _buildDayRow('Friday', weeklyAdherenceRates['Friday'] ?? 0),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Saturday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Saturday'] ?? 0),
                          child: _buildDayRow('Saturday', weeklyAdherenceRates['Saturday'] ?? 0),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () => _showDayDetails(context, 'Sunday'),
                        child: Tooltip(
                          message: _getAdherenceMessage(weeklyAdherenceRates['Sunday'] ?? 0),
                          child: _buildDayRow('Sunday', weeklyAdherenceRates['Sunday'] ?? 0),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}