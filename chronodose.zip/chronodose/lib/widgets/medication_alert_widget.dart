import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';

class MedicationAlertWidget extends StatefulWidget {
  final String scheduleId;
  final Function()? onTaken;
  final Function()? onDismissed;
  
  const MedicationAlertWidget({
    Key? key,
    required this.scheduleId,
    this.onTaken,
    this.onDismissed,
  }) : super(key: key);

  @override
  State<MedicationAlertWidget> createState() => _MedicationAlertWidgetState();
}

class _MedicationAlertWidgetState extends State<MedicationAlertWidget> {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  String medicineName = 'Medication';
  String doseInfo = '';
  DateTime? scheduledTime;
  bool isLoading = true;
  bool error = false;
  
  @override
  void initState() {
    super.initState();
    _loadScheduleDetails();
  }
  
  Future<void> _loadScheduleDetails() async {
    try {
      final snapshot = await _database.child('schedules/${widget.scheduleId}').get();
      
      if (snapshot.exists) {
        final data = snapshot.value as Map<dynamic, dynamic>;
        
        setState(() {
          medicineName = data['medicines'] ?? 'Medication';
          
          // Parse time if available
          if (data.containsKey('time')) {
            final timeData = data['time'] as Map<dynamic, dynamic>;
            final hour = timeData['hour'] as int;
            final minute = timeData['minute'] as int;
            
            // Set scheduled time to today with this hour/minute
            final now = DateTime.now();
            scheduledTime = DateTime(now.year, now.month, now.day, hour, minute);
            
            // Format dosage information if available
            if (data.containsKey('dosage')) {
              doseInfo = data['dosage'].toString();
            }
          }
          
          isLoading = false;
        });
      } else {
        setState(() {
          error = true;
          isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading schedule details: $e');
      setState(() {
        error = true;
        isLoading = false;
      });
    }
  }
  
  Future<void> _markAsTaken() async {
  try {
    // Update status in Firebase
    await _database.child('dispenser/status').update({
      'status': 'taken',
      'scheduleId': widget.scheduleId,
      'takenAt': ServerValue.timestamp,
    });
    
    // Call the onTaken callback if provided
    if (widget.onTaken != null) {
      widget.onTaken!();
    }
  } catch (e) {
    print('Error marking medication as taken: $e');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Failed to mark medication as taken'))
    );
  }
}

Future<void> _dismiss() async {
  if (widget.onDismissed != null) {
    widget.onDismissed!();
  }
}

@override
Widget build(BuildContext context) {
  if (isLoading) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Center(child: CircularProgressIndicator()),
      ),
    );
  }
  
  if (error) {
    return Card(
      color: Colors.red[50],
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Error loading medication details',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _loadScheduleDetails,
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }
  
  final timeString = scheduledTime != null
      ? DateFormat('h:mm a').format(scheduledTime!)
      : 'Now';
  
  return Card(
    elevation: 4,
    color: Theme.of(context).colorScheme.primaryContainer,
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.medication, 
                color: Theme.of(context).colorScheme.primary, 
                size: 32,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Time to take your medication',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    Text(
                      timeString,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            medicineName,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          if (doseInfo.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              'Dosage: $doseInfo',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              OutlinedButton.icon(
                onPressed: _dismiss,
                icon: const Icon(Icons.notifications_off),
                label: const Text('Dismiss'),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: _markAsTaken,
                icon: const Icon(Icons.check_circle),
                label: const Text('Mark as Taken'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  foregroundColor: Theme.of(context).colorScheme.onPrimary,
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
}