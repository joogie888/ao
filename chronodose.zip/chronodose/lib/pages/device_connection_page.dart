import 'dart:async';

import 'package:chronodose/services/firebase_dispenser_service.dart';
import 'package:flutter/material.dart';

class DispenserConnectionPage extends StatefulWidget {
  @override
  _DispenserConnectionPageState createState() => _DispenserConnectionPageState();
}

class _DispenserConnectionPageState extends State<DispenserConnectionPage> {
  final FirebaseDispenserService _dispenserService = FirebaseDispenserService();
  late Function(String, Map<String, dynamic>?) _myEventListener;

  bool _isConnecting = false;
  bool _isConnected = false;
  String _statusMessage = "Not connected";
  Map<String, dynamic>? _deviceInfo;
  Duration? _timeDrift;
  DateTime? _lastSyncTime;
  Timer? _statusCheckTimer;

  @override
  void initState() {
    super.initState();
  
    _isConnected = _dispenserService.isConnected;
  
    // If already connected, immediately show connected state
    if (_isConnected) {
      _statusMessage = "Connected to dispenser";
      _loadDeviceInfo(); // Add this method to load existing device info
    } else {
      _statusMessage = "Not Connected";
    }
  
    // Set up listeners and check status
    _setupEventListener();
    _checkInitialConnectionStatus();  
  }

  @override
  void dispose() {
    _statusCheckTimer?.cancel();
    _dispenserService.removeSpecificEventListener(_myEventListener);

    super.dispose();
  }

  Future<void> _loadDeviceInfo() async {
    try {
      final deviceInfo = await _dispenserService.getDeviceInfo();
      if (deviceInfo != null && mounted) {
        setState(() {
          _deviceInfo = deviceInfo;
        });
        _checkTimeDrift();
      }
    } catch (e) {
      print("Error loading device info: $e");
    }
  }

  Future<void> _checkInitialConnectionStatus() async {
  try {
    // First, check if the service thinks we're connected
    bool serviceConnected = _dispenserService.isConnected;
    
    if (serviceConnected) {
      // If service thinks we're connected, update UI immediately
      if (mounted) {
        setState(() {
          _isConnected = true;
          _statusMessage = "Device online";
        });
      }
      
      // Load device info
      final deviceInfo = await _dispenserService.getDeviceInfo();
      if (deviceInfo != null && mounted) {
        setState(() {
          _deviceInfo = deviceInfo;
          
          // Double check the online status from the device info
          if (deviceInfo.containsKey('status')) {
            bool deviceSaysOnline = deviceInfo['status'] == 'online';
            // Only update UI if it changes our understanding
            if (_isConnected != deviceSaysOnline) {
              _isConnected = deviceSaysOnline;
              _statusMessage = deviceSaysOnline ? "Device online" : "Device offline";
            }
          }
        });
        _checkTimeDrift();
      }
    } else {
      // If service thinks we're disconnected, do a more thorough check
      setState(() {
        _statusMessage = "Checking connection...";
      });
      
      final deviceInfo = await _dispenserService.getDeviceInfo();
      if (deviceInfo != null && mounted) {
        // Check if the device is truly online with multiple criteria
        final bool claimsOnline = deviceInfo['status'] == 'online';
        
        // Check if lastSeen is recent (within last 2 minutes)
        bool isRecent = false;
        if (deviceInfo['lastSeen'] != null) {
          final lastSeenTime = DateTime.fromMillisecondsSinceEpoch(deviceInfo['lastSeen'] * 1000);
          final difference = DateTime.now().difference(lastSeenTime);
          isRecent = difference.inMinutes < 2;
        }
        
        // Try a ping if possible
        bool connectivityVerified = false;
        if (claimsOnline && isRecent) {
          try {
            connectivityVerified = await _dispenserService.pingDevice() ?? false;
          } catch (e) {
            connectivityVerified = false;
          }
        }
        
        // Consider online if multiple checks pass
        final bool trulyOnline = claimsOnline && isRecent && (connectivityVerified || !_dispenserService.supportsPing);
        
        if (mounted) {
          setState(() {
            _deviceInfo = deviceInfo;
            _isConnected = trulyOnline;
            _statusMessage = trulyOnline ? "Device online" : "Device offline";
          });
          
          if (trulyOnline) {
            _checkTimeDrift();
          }
        }
      } else if (mounted) {
        setState(() {
          _isConnected = false;
          _statusMessage = "No device information available";
        });
      }
    }
  } catch (e) {
    if (mounted) {
      setState(() {
        _statusMessage = "Error checking status: $e";
      });
    }
  }
}

void _setupEventListener() {
  _myEventListener = (eventType, data) {
      if (!mounted) return;
      
      print("Dispenser event received: $eventType");
      
      if (eventType == FirebaseDispenserService.EVENT_DEVICE_ONLINE) {
        setState(() {
          _isConnected = true;
          _statusMessage = "Device online";
          if (data != null) {
            _deviceInfo = data;
          }
        });
        _checkTimeDrift();
      } else if (eventType == FirebaseDispenserService.EVENT_DEVICE_OFFLINE) {
        setState(() {
          _isConnected = false;
          _statusMessage = "Device offline";
        });
      } else if (eventType == FirebaseDispenserService.EVENT_INFO_UPDATE) {
        setState(() {
          if (data != null) {
            _deviceInfo = data;
            // Check if status indicates online
            if (data.containsKey('status')) {
              _isConnected = data['status'] == 'online';
            }
          }
        });
      } else if (eventType == FirebaseDispenserService.EVENT_STATUS_CHANGE) {
        if (data != null) {
          setState(() {
            if (data.containsKey('status')) {
              _isConnected = data['status'] == 'online';
              _statusMessage = _isConnected ? "Device online" : "Device offline";
            }
          });
        }
      }
    };
    
    _dispenserService.setDispenserEventListener(_myEventListener);
}


  Future<void> _checkTimeDrift() async {
    if (!_isConnected) return;
    
    final drift = await _dispenserService.checkTimeDrift();
    if (drift != null) {
      setState(() {
        _timeDrift = drift;
      });
    }
  }
  Future<void> _syncTime() async {
  if (!_isConnected) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Device not connected'))
    );
    return;
  }
  
  setState(() {
    _statusMessage = "Syncing time...";
  });
  
  try {
    final success = await _dispenserService.sendTimeToDevice(DateTime.now());
    
    setState(() {
      _statusMessage = success ? "Time synced successfully" : "Time sync failed";
      if (success) {
        _lastSyncTime = DateTime.now();
        _timeDrift = Duration.zero;
      }
    });
    
    // Show result
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? 'Time synchronized successfully' : 'Time sync failed'))
    );
  } catch (e) {
    setState(() {
      _statusMessage = "Time sync error: $e";
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Time sync error: $e'))
    );
  }
}

  Future<void> _connectToDispenser() async {
  setState(() {
    _isConnecting = true;
    _statusMessage = "Connecting...";
  });

  try {
    final connected = await _dispenserService.connectToDispenser();
    
    // Double-check with a direct status query
    final deviceInfo = await _dispenserService.getDeviceInfo();
    final bool reallyConnected = connected && 
        deviceInfo != null && 
        deviceInfo['status'] == 'online';
    
    setState(() {
      _isConnected = reallyConnected;
      _isConnecting = false;
      _statusMessage = reallyConnected 
          ? "Connected to dispenser" 
          : "Failed to connect - dispenser appears to be offline";
    });
    
    if (reallyConnected) {
      setState(() {
        _deviceInfo = deviceInfo;
      });
      
      await _checkTimeDrift();
      
      if (_timeDrift != null && _timeDrift!.abs().inMinutes >= 2) {
        await _syncTime();
      }
    }
  } catch (e) {
    setState(() {
      _isConnected = false;
      _isConnecting = false;
      _statusMessage = "Error: $e";
    });
  }
}

  @override
  Widget build(BuildContext context) {
    final bool currentConnectionStatus = _dispenserService.isConnected;
  if (_isConnected != currentConnectionStatus) {
    // Use a post-frame callback to avoid rebuilding during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _isConnected = currentConnectionStatus;
        });
      }
    });
  }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop(); // This will navigate back to the previous page
          },
        ),
        title: Text('Dispenser Connection'),
        actions: [
          IconButton(
              icon: Icon(Icons.refresh),
              tooltip: 'Refresh Status',
              onPressed: () {
                setState(() {
                  _statusMessage = "Refreshing...";
                  _isConnected = false; // Temporarily mark as disconnected during refresh
                });
                _checkInitialConnectionStatus();
              },
            ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status indicator
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _isConnected ? Colors.green.shade100 : Colors.red.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(
                    _isConnected ? Icons.check_circle : Icons.error_outline,
                    color: _isConnected ? Colors.green : Colors.red,
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      _statusMessage,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: 24),
            
            // Device info
            if (_deviceInfo != null) ...[
              Text(
                'Device Information',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text('Version: ${_deviceInfo!['version'] ?? 'Unknown'}'),
              Text('WiFi Signal: ${_deviceInfo!['wifiSignal'] ?? 'Unknown'} dBm'),
              Text('Schedules: ${_deviceInfo!['scheduleCount'] ?? '0'}'),
              Text('Last Seen: ${_formatTimestamp(_deviceInfo!['lastSeen'])}'),
              
              // Display time drift if available
              if (_timeDrift != null) ...[
              SizedBox(height: 8),
              Row(
                children: [
                  Text(
                    'Time Drift: ${_formatDrift(_timeDrift!)}',
                    style: TextStyle(
                    color: _isDriftSignificant(_timeDrift!) ? Colors.red : Colors.green,
                    fontWeight: _isDriftSignificant(_timeDrift!) ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
              SizedBox(width: 8),
              // Regular sync button
              if (_isDriftSignificant(_timeDrift!))
                ElevatedButton(
                  onPressed: _syncTime,
                  child: Text('Sync Time'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
            // Add force sync button with extended timeout
            SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () async {
              setState(() {
                _statusMessage = "Force syncing time (extended timeout)...";
              });
    
              // Call the enhanced force time sync function
              final success = await _dispenserService.forceTimeSync(
                DateTime.now(),
                extendedTimeout: 30  // Use a longer timeout for force sync
              );
              
              setState(() {
                _statusMessage = success ? "Time force-synced successfully" : "Force time sync failed";
                if (success) {
                  _lastSyncTime = DateTime.now();
                  _timeDrift = Duration.zero;
                }
              });
              
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(success ? 'Force time sync successful' : 'Force time sync failed'))
              );
            },
            icon: Icon(Icons.av_timer),
            label: Text('Force Sync (Extended Timeout)'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
          ),
      ],
              
              // Show last sync time if available
              if (_lastSyncTime != null) ...[
                SizedBox(height: 4),
                Text(
                  'Last Synced: ${_formatDateTime(_lastSyncTime!)}',
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
              ],
              
              SizedBox(height: 16),
            ],
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _isConnecting ? null : _connectToDispenser,
        child: _isConnecting
            ? CircularProgressIndicator(color: Colors.white)
            : Icon(Icons.refresh),
        tooltip: 'Connect to Dispenser',
      ),
    );
  }
  
  String _formatTimestamp(dynamic timestamp) {
    if (timestamp == null) return 'Unknown';
    try {
      final dateTime = DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
      return '${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return 'Invalid timestamp';
    }
  }
  
  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
  
  String _formatDrift(Duration drift) {
    final minutes = drift.inMinutes;
    final seconds = drift.inSeconds % 60;
    
    if (minutes == 0) {
      return '$seconds seconds';
    } else {
      return '$minutes min, $seconds sec';
    }
  }
  
  bool _isDriftSignificant(Duration drift) {
    // Consider drift significant if more than 1 minute
    return drift.abs().inMinutes >= 1;
  }
}