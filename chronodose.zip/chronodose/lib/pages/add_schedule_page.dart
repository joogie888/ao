import 'package:flutter/material.dart';
import '../models/schedule.dart';
import '../services/firebase_schedule_service.dart';

class AddSchedulePage extends StatefulWidget {
  final Schedule? scheduleToEdit;
  
  const AddSchedulePage({super.key, this.scheduleToEdit});
  
  @override
  State<AddSchedulePage> createState() => _AddSchedulePageState();
}

class _AddSchedulePageState extends State<AddSchedulePage> {
  late TimeOfDay _selectedTime;
  late TextEditingController _medicinesController;
  bool _isEnabled = true;
  bool _isSaving = false;
  final FirebaseScheduleService _scheduleService = FirebaseScheduleService();
  
  @override
  void initState() {
    super.initState();
    _selectedTime = widget.scheduleToEdit?.time ?? TimeOfDay.now();
    
    // Handle medicines - could be String or List<String>
    String initialMedicines = '';
    if (widget.scheduleToEdit?.medicines != null) {
      if (widget.scheduleToEdit!.medicines is List) {
        initialMedicines = (widget.scheduleToEdit!.medicines as List).join(', ');
      } else if (widget.scheduleToEdit!.medicines is String) {
        initialMedicines = widget.scheduleToEdit!.medicines as String;
      }
    }
    
    _medicinesController = TextEditingController(text: initialMedicines);
    _isEnabled = widget.scheduleToEdit?.isEnabled ?? true;
  }
  
  @override
  void dispose() {
    _medicinesController.dispose();
    super.dispose();
  }
  
  // Convert medicines text to list format for Firebase
  List<String> _parseMedicines(String text) {
    if (text.isEmpty) return [];
    
    // Split by commas and trim whitespace
    return text.split(',').map((med) => med.trim()).where((med) => med.isNotEmpty).toList();
  }
  
  Future<void> _saveSchedule() async {
    if (_medicinesController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter medicines')),
      );
      return;
    }
    
    setState(() {
      _isSaving = true;
    });
    
    try {
      // Prepare medicines as list for Firebase
      final medicinesList = _parseMedicines(_medicinesController.text);
      
      final schedule = Schedule(
        id: widget.scheduleToEdit?.id,
        time: _selectedTime,
        medicines: medicinesList,
        isEnabled: _isEnabled,
      );
      
      Schedule? result;
      if (widget.scheduleToEdit != null) {
        // Update existing schedule
        final success = await _scheduleService.updateSchedule(schedule);
        if (success) {
          result = schedule;
        }
      } else {
        // Create new schedule
        result = await _scheduleService.addSchedule(schedule);
      }
      
      // Debug print to check if the schedule was saved
      print('Schedule saved successfully: ${result?.id}');
      
      if (mounted) {
        // Make sure to pop with result data and ensure navigation happens
        // Added a slight delay to ensure state is properly updated
        Future.delayed(Duration.zero, () {
          Navigator.pop(context, result);
        });
      }
    } catch (e) {
      print('Error saving schedule: $e');
      
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving schedule: ${e.toString()}')),
        );
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.scheduleToEdit == null ? 'Add Schedule' : 'Edit Schedule',
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blue.shade300,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Time',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    InkWell(
                      onTap: () async {
                        final TimeOfDay? time = await showTimePicker(
                          context: context,
                          initialTime: _selectedTime,
                          builder: (context, child) {
                            return Theme(
                              data: Theme.of(context).copyWith(
                                colorScheme: ColorScheme.light(
                                  primary: Colors.blue.shade300,
                                ),
                              ),
                              child: child!,
                            );
                          },
                        );
                        if (time != null) {
                          setState(() {
                            _selectedTime = time;
                          });
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${_selectedTime.hour}:${_selectedTime.minute.toString().padLeft(2, '0')} ${_selectedTime.period.name.toUpperCase()}',
                              style: const TextStyle(fontSize: 18),
                            ),
                            Icon(
                              Icons.access_time,
                              color: Colors.blue.shade300,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Medications',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _medicinesController,
                      decoration: InputDecoration(
                        hintText: 'Enter medicine names, dosages, etc. (separate with commas)',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: Colors.grey.shade300),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: Colors.blue.shade300, width: 2),
                        ),
                      ),
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Status toggle
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Enable Schedule',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Switch(
                      value: _isEnabled,
                      activeColor: Colors.blue.shade300,
                      onChanged: (value) {
                        setState(() {
                          _isEnabled = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            // Save button
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _saveSchedule,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade300,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 3,
                ),
                child: _isSaving
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: Colors.white,
                        ),
                      )
                    : Text(
                        widget.scheduleToEdit == null ? 'Add Schedule' : 'Update Schedule',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}