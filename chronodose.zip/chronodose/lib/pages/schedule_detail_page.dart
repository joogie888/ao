import 'dart:convert';
import 'package:chronodose/pages/home_page.dart';
import 'package:flutter/material.dart';
import '../services/firebase_schedule_service.dart';
import 'add_schedule_page.dart';
import '../models/schedule.dart';

class ScheduleDetailPage extends StatefulWidget {
  final List<Schedule> schedules;
  
  const ScheduleDetailPage({super.key, required this.schedules});

  @override
  State<ScheduleDetailPage> createState() => _ScheduleDetailPageState();
}

class _ScheduleDetailPageState extends State<ScheduleDetailPage> {
  late List<Schedule> _schedules;
  final FirebaseScheduleService _scheduleService = FirebaseScheduleService();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _schedules = List.from(widget.schedules);
    _sortSchedules();
    _loadSchedules(); // Fetch latest schedules from Firebase
  }

  // Load all schedules from Firebase
  Future<void> _loadSchedules() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final fetchedSchedules = await _scheduleService.getSchedules();
      
      if (mounted) {
        setState(() {
          _schedules = fetchedSchedules;
          _sortSchedules();
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading schedules: $e');
      
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading schedules: ${e.toString()}')),
        );
      }
    }
  }

  void _sortSchedules() {
    _schedules.sort((a, b) {
      final aHour = _convertTo24Hour(a.time);
      final bHour = _convertTo24Hour(b.time);
      return _compareTime(aHour, a.time.minute, bHour, b.time.minute);
    });
  }

  // Helper method to convert time to 24-hour format
  int _convertTo24Hour(TimeOfDay time) {
    int hour = time.hour;
    if (time.period == DayPeriod.pm && hour != 12) {
      hour += 12;
    }
    if (time.period == DayPeriod.am && hour == 12) {
      hour = 0;
    }
    return hour;
  }

  // Compare two times for sorting
  String _formatMedicines(dynamic medicines) {
  if (medicines == null) {
    return "";
  } else if (medicines is List) {
    return medicines.join(", ");
  } else if (medicines is String) {
    // If it's a raw string but might be intended as a list
    if (medicines.startsWith("[") && medicines.endsWith("]")) {
      try {
        // Try to parse it as a list
        final parsed = json.decode(medicines);
        if (parsed is List) {
          return parsed.join(", ");
        }
      } catch (_) {
        // If parsing fails, just return the string
      }
    }
    // Return the original string if it's not in list format
    return medicines;
  } else if (medicines is Map) {
    // Handle map case if needed
    return medicines.values.join(", ");
  }
  return medicines.toString();
}

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final fetchedSchedules = await _scheduleService.getSchedules();
      // Update HomePage.schedules with this data
        HomePage.schedules = fetchedSchedules;
        
        try {
          if (HomePage.currentHomeViewState != null) {
            // Use Future.microtask to ensure this runs after navigation completes
            Future.microtask(() {
              HomePage.currentHomeViewState!.refreshNextDose();
            });
          }
        } catch (e) {
          print("Failed to refresh HomeView: $e");
        }
        
        // Allow the navigation to proceed
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Schedule Details',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.blue.shade300,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.pop(context, _schedules);
            },
          ),
          actions: [
            // Refresh button
            IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: _loadSchedules,
            ),
          ],
        ),
        body: _isLoading 
            ? const Center(child: CircularProgressIndicator())
            : (_schedules.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'No schedules yet',
                          style: TextStyle(color: Colors.grey, fontSize: 18),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () async {
                            await _navigateToAddSchedule();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue.shade300,
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Add New Schedule'),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _schedules.length,
                    itemBuilder: (context, index) {
                      final schedule = _schedules[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.1),
                              spreadRadius: 1,
                              blurRadius: 5,
                            ),
                          ],
                          border: schedule.isEnabled != false // Account for null values
                              ? Border.all(color: Colors.blue.shade100, width: 1)
                              : Border.all(color: Colors.grey.shade300, width: 1),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.access_time,
                                  color: schedule.isEnabled != false // Account for null values
                                      ? Colors.blue.shade300
                                      : Colors.grey,
                                  size: 24,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  '${schedule.time.hour}:${schedule.time.minute.toString().padLeft(2, '0')} ${schedule.time.period.name.toUpperCase()}',
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500,
                                    color: schedule.isEnabled != false // Account for null values
                                        ? Colors.black87
                                        : Colors.grey,
                                  ),
                                ),
                                const Spacer(),
                                // Status toggle
                                Switch(
                                  value: schedule.isEnabled ?? true,
                                  activeColor: Colors.blue.shade300,
                                  onChanged: (value) async {
                                    final updatedSchedule = Schedule(
                                      id: schedule.id,
                                      time: schedule.time,
                                      medicines: schedule.medicines,
                                      isEnabled: value,
                                    );
                                    
                                    setState(() {
                                      _isLoading = true;
                                    });
                                    
                                    final success = await _scheduleService.updateSchedule(updatedSchedule);
                                    
                                    if (mounted) {
                                      setState(() {
                                        _isLoading = false;
                                        if (success) {
                                          final idx = _schedules.indexWhere((s) => s.id == schedule.id);
                                          if (idx != -1) {
                                            _schedules[idx] = updatedSchedule;
                                          }
                                        } else {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(content: Text('Failed to update schedule status')),
                                          );
                                        }
                                      });
                                    }
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.edit),
                                  onPressed: () => _editSchedule(schedule),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () => _deleteSchedule(index, schedule),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Medicines: ${_formatMedicines(schedule.medicines)}',
                              style: TextStyle(
                                fontSize: 16,
                                color: schedule.isEnabled != false // Account for null values
                                    ? Colors.black87
                                    : Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  )),
        floatingActionButton: FloatingActionButton(
          onPressed: _navigateToAddSchedule,
          backgroundColor: Colors.blue.shade300,
          child: const Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }

  // Navigate to add schedule page
  Future<void> _navigateToAddSchedule() async {
    print('Navigating to AddSchedulePage');
    
    final result = await Navigator.push<Schedule>(
      context,
      MaterialPageRoute(builder: (context) => const AddSchedulePage()),
    );
    
    print('Returned from AddSchedulePage with result: ${result?.id}');
    
    if (result != null) {
      setState(() {
        _isLoading = true;
      });
      
      await _handleScheduleResult(result, isNew: true);
      
      // Also update HomePage.schedules to ensure consistency
      final latestSchedules = await _scheduleService.getSchedules();
      HomePage.schedules = latestSchedules;
      
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Edit schedule
  Future<void> _editSchedule(Schedule schedule) async {
    print('Editing schedule: ${schedule.id}');
    
    final result = await Navigator.push<Schedule>(
      context,
      MaterialPageRoute(
        builder: (context) => AddSchedulePage(
          scheduleToEdit: schedule,
        ),
      ),
    );
    
    print('Returned from edit with result: ${result?.id}');
    
    if (result != null) {
      setState(() {
        _isLoading = true;
      });
      
      await _handleScheduleResult(result, isNew: false);
      
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Delete schedule
  Future<void> _deleteSchedule(int index, Schedule schedule) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Schedule'),
        content: const Text('Are you sure you want to delete this schedule?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'Delete',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    ) ?? false;
    
    if (confirm && schedule.id != null) {
      setState(() {
        _isLoading = true;
      });
      
      // Delete from Firebase
      final success = await _scheduleService.deleteSchedule(schedule.id!);
      
      if (mounted) {
        setState(() {
          _isLoading = false;
          if (success) {
            _schedules.removeAt(index);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Failed to delete schedule')),
            );
          }
        });
      }
    }
  }
  
  // Handle adding or editing a schedule
  Future<void> _handleScheduleResult(Schedule result, {required bool isNew}) async {
    print('Handling schedule result: ${result.id}, isNew: $isNew');
  
    try {
      if (isNew) {
        // For new schedules, reload the full list from Firebase to ensure consistency
        final updatedSchedules = await _scheduleService.getSchedules();
        setState(() {
          _schedules = updatedSchedules;
          _sortSchedules();
        });
        print('Refreshed schedules from Firebase, total: ${_schedules.length}');
      } else {
      // For edited schedules
      final idx = _schedules.indexWhere((s) => s.id == result.id);
      if (idx != -1) {
        setState(() {
          _schedules[idx] = result;
          _sortSchedules();
        });
        print('Updated existing schedule in list');
      } else {
        print('Could not find schedule with ID ${result.id} in list');
      }
    }
  } catch (e) {
    print('Error handling schedule result: $e');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }
}
  
  int _compareTime(int hour1, int minute1, int hour2, int minute2) {
  if (hour1 != hour2) {
    return hour1 - hour2;
  }
  return minute1 - minute2;
}
}