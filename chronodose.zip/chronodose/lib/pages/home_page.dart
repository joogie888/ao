import 'dart:async';

import 'package:chronodose/pages/schedule_detail_page.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'device_connection_page.dart';
import 'medication_log_page.dart';
import '../models/schedule.dart';
import '../services/firebase_schedule_service.dart';
import '../services/firebase_dispenser_service.dart';
import '../widgets/home_view.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  static List<Schedule> schedules = [];
  static DateTime refillDate = DateTime(2025, 1, 1);

  static HomeViewState? currentHomeViewState;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final FirebaseScheduleService _scheduleService = FirebaseScheduleService();
  final FirebaseDispenserService _dispenserService = FirebaseDispenserService();
  bool _isLoading = true;
  bool _isDispenserConnected = false;
  
  // For push notifications
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  late Function(String, Map<String, dynamic>?) _myHomePageEventListener;

  StreamSubscription? _foregroundMessageSubscription;
  StreamSubscription? _backgroundMessageSubscription;

   @override
  void dispose() {
    _dispenserService.removeSpecificEventListener(_myHomePageEventListener);
    _foregroundMessageSubscription?.cancel();
    _backgroundMessageSubscription?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _isDispenserConnected = _dispenserService.isConnected;
    _loadData();
    _initializeConnection();
    _setupNotifications();
  }

  void _setupDispenserEventListener() {
    _myHomePageEventListener = (event, data) {
      // Your existing event handling code
    };
    _dispenserService.setDispenserEventListener(_myHomePageEventListener);
  }

  void refreshNextDose() {
    if (mounted) {
      setState(() {
        // Force UI refresh
      });
    }
  }

  void _navigateToScheduleDetail() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScheduleDetailPage(schedules: HomePage.schedules),
      ),
    ).then((_) {
      // This will be called when returning from ScheduleDetailPage
      _loadData(); // Reload all data including schedules
    });
  }

  Future<void> _setupNotifications() async {
    try {
      // Request permission for notifications
      NotificationSettings settings = await _firebaseMessaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );
      
      print('User granted permission: ${settings.authorizationStatus}');
      
      // Configure foreground notification handling - store subscription
      _foregroundMessageSubscription = FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        if (!mounted) return;  // Add this check
        
        print('Got a message whilst in the foreground!');
        print('Message data: ${message.data}');

        if (message.notification != null) {
          print('Message also contained a notification: ${message.notification}');
          
          // Show an in-app notification
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(message.notification!.title ?? 'Medication reminder'),
              duration: const Duration(seconds: 5),
            ),
          );
        }
        
        // Reload data if the message indicates a medication was taken
        if (message.data['type'] == 'medication_taken') {
          _loadData();
        }
      });
      
      // Handle notification clicks when app is in background - store subscription
      _backgroundMessageSubscription = FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        if (!mounted) return;  // Add this check
        
        print('A notification was clicked on: ${message.data}');
        
        // Navigate based on notification type
        if (message.data['type'] == 'medication_taken') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const MedicationLogPage(),
            ),
          );
        }
      });
    } catch (e) {
      print("Error setting up notifications: $e");
    }
  }

 Future<void> _initializeConnection() async {
  try {
    // Check if already connected
    setState(() {
      _isDispenserConnected = _dispenserService.isConnected;
    });
    
    // Set up listener regardless of connection state
    _setupDispenserEventListener();
    
    // Only try to connect if not already connected
    if (!_isDispenserConnected) {
      bool connected = await _dispenserService.connectToDispenser();
      
      if (!mounted) return;
      
      setState(() {
        _isDispenserConnected = connected;
      });
      
      if (connected) {
        // Sync current time with dispenser
        await _dispenserService.sendTimeToDevice(DateTime.now());
        
        // Send current schedules to device
        await _dispenserService.sendSchedulesToDevice(HomePage.schedules);
      }
    }
  } catch (e) {
    print("Failed to initialize connection: $e");
    if (mounted) {
      setState(() {
        _isDispenserConnected = false;
      });
    }
  }
}


  void _handlePillConfirmation(Map<String, dynamic> data) {
  try {
    if (!mounted) return;  // Add this check
    
    String scheduleId = data['id'];
    DateTime timestamp = DateTime.parse(data['timestamp']);
    
    // Update database
    _scheduleService.markScheduleAsTaken(scheduleId, timestamp);
    
    // Show notification to user
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Medication taken at ${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}")),
    );
    
    // Reload data to reflect changes
    _loadData();
  } catch (e) {
    print("Error handling pill confirmation: $e");
  }
}

  Future<void> _loadData() async {
    if (!mounted) return;
    
    setState(() {
      _isLoading = true;
    });
    
    print("Loading data started");
    
    try {
      // Always load schedules from Firebase as the source of truth
      final schedules = await _scheduleService.getSchedules();
      print("Loaded schedules: ${schedules.length}");
      
      // Load refill date
      final refillDate = await _scheduleService.getRefillDate();
      print("Loaded refill date: $refillDate");
      
      if (mounted) {
        setState(() {
          // Always use the Firebase data as the source of truth
          HomePage.schedules = schedules;
          if (refillDate != null) {
            HomePage.refillDate = refillDate;
          }
          _isLoading = false;
        });
      }
      print("Loading data finished. _isLoading = $_isLoading");
    } catch (e) {
      print("Error loading data: $e");
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {  
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          'CHRONODOSE',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.blue.shade300,
        actions: [
          // Device connection status indicator
          IconButton(
            icon: Icon(
              _isDispenserConnected ? Icons.link : Icons.link_off,
              color: _isDispenserConnected ? Colors.green : Colors.white,
            ),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DispenserConnectionPage(),
                ),
              ).then((_) {
                setState(() {
                  _isDispenserConnected = _dispenserService.isConnected;
                });
              });
            },
          ),
        ],
      ),
      body: _isLoading 
          ? const Center(child: CircularProgressIndicator())
        : HomeView(
            onScheduleToggled: _handleScheduleToggle,
            dispenserConnected: _isDispenserConnected,
            onSelectRefillDate: _selectDate,
            onRefresh: _loadData,
          ),
    );
  }
  
  Future<void> _handleScheduleToggle(Schedule schedule, bool value) async {
    // Create a new schedule with updated enabled status
    final updatedSchedule = Schedule(
      id: schedule.id,
      medicines: schedule.medicines,
      time: schedule.time,
      isEnabled: value,
    );
    
    // Update in Firebase
    final success = await _scheduleService.updateSchedule(updatedSchedule);
    
    if (success) {
      // Reload all schedules from Firebase to ensure consistency
      await _loadData();
      
      // Update on device if connected
      if (_isDispenserConnected) {
        _dispenserService.sendSchedulesToDevice(HomePage.schedules);
      }

    } else {
      // Show error
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to update schedule')),
      );
    }
  }
  
  Future<void> _selectDate(BuildContext context) async {
    try {
      // Make sure initialDate is within the allowed range
      DateTime initialDate = HomePage.refillDate;
      DateTime now = DateTime.now();
      
      // If the stored date is in the past, use today's date instead
      if (initialDate.isBefore(now)) {
        initialDate = now;
      }
      
      final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: now,
        lastDate: DateTime(2036),
      );
      
      if (picked != null && picked != HomePage.refillDate) {
        // Save the new refill date to the database
        final savedDate = await _scheduleService.saveRefillDate(picked);
        
        if (savedDate != null && mounted) {
          setState(() {
            HomePage.refillDate = savedDate;
          });
          
          // Force refresh next dose - place it here, after we have savedDate
          if (HomePage.currentHomeViewState != null) {
            HomePage.currentHomeViewState!.refreshNextDose();
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to save refill date')),
          );
        }
      }
    } catch (e) {
      print('Error selecting date: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to change date: $e')),
      );
    }
  }
}