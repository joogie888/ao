import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/medication_log.dart';

class MedicationLogPage extends StatefulWidget {
  final DateTime? filterDate;
  
  const MedicationLogPage({Key? key, this.filterDate}) : super(key: key);

  @override
  State<MedicationLogPage> createState() => _MedicationLogPageState();
}

class _MedicationLogPageState extends State<MedicationLogPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _deviceId = 'device_default_id'; // Should match the one in FirebaseScheduleService
  List<MedicationLog> _logs = [];
  bool _isLoading = true;
  String _selectedFilter = 'All';
  final List<String> _filterOptions = ['All', 'Today', 'This Week', 'This Month'];
  
  @override
  void initState() {
    super.initState();
    _loadLogs();
  }
  
  Future<void> _loadLogs() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      // Get date ranges based on filter
      DateTime? startDate;
      if (_selectedFilter == 'Today') {
        final now = DateTime.now();
        startDate = DateTime(now.year, now.month, now.day);
      } else if (_selectedFilter == 'This Week') {
        startDate = DateTime.now().subtract(const Duration(days: 7));
      } else if (_selectedFilter == 'This Month') {
        startDate = DateTime.now().subtract(const Duration(days: 30));
      }
      
      // Build query
      Query query = _firestore
          .collection('medication_log') // Use the correct collection name
          .where('deviceId', isEqualTo: _deviceId) // Add device ID filter
          .orderBy('takenAt', descending: true);
      
      // Apply date filtering if needed
      if (startDate != null) {
        query = query.where('takenAt', isGreaterThanOrEqualTo: Timestamp.fromDate(startDate));
      }
      
      final querySnapshot = await query.get();
      
      final logs = querySnapshot.docs.map<MedicationLog>((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return MedicationLog.fromFirestore(data, doc.id);
      }).toList();
      
      setState(() {
        _logs = logs;
        _isLoading = false;
      });
    } catch (e) {
      print('Error fetching medication logs: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Medication Log',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.blue.shade300,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadLogs,
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter options
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Filter by:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                DropdownButton<String>(
                  value: _selectedFilter,
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _selectedFilter = newValue;
                      });
                      _loadLogs();
                    }
                  },
                  items: _filterOptions.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          
          // Logs list
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _logs.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.medication_outlined,
                              size: 72,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No medication logs found',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _logs.length,
                        itemBuilder: (context, index) {
                          final log = _logs[index];
                          final bool isToday = _isToday(log.takenAt);
                          
                          // Group logs by date
                          final bool showDateHeader = index == 0 || 
                              !_isSameDay(_logs[index].takenAt, _logs[index - 1].takenAt);
                          
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (showDateHeader)
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 16.0, 
                                    right: 16.0, 
                                    top: 16.0, 
                                    bottom: 8.0
                                  ),
                                  child: Text(
                                    isToday 
                                        ? 'Today' 
                                        : DateFormat.yMMMd().format(log.takenAt),
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: Colors.grey.shade800,
                                    ),
                                  ),
                                ),
                              _buildLogItem(log),
                            ],
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildLogItem(MedicationLog log) {
    // Get the scheduled time
    final scheduledTime = TimeOfDay(hour: log.scheduledHour, minute: log.scheduledMinute);
    
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: Colors.blue.shade100,
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.medication,
            color: Colors.blue.shade700,
            size: 24,
          ),
        ),
        title: Text(
          log.medicinesDisplay,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.calendar_today, size: 14, color: Colors.grey.shade600),
                const SizedBox(width: 4),
                Text(
                  DateFormat.yMMMd().format(log.takenAt),
                  style: TextStyle(color: Colors.grey.shade800),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.access_time, size: 14, color: Colors.grey.shade600),
                const SizedBox(width: 4),
                Text(
                  'Taken: ${DateFormat.jm().format(log.takenAt)}',
                  style: TextStyle(color: Colors.grey.shade800),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.alarm, size: 14, color: Colors.grey.shade600),
                const SizedBox(width: 4),
                Text(
                  'Scheduled: ${scheduledTime.format(context)}',
                  style: TextStyle(color: Colors.grey.shade800),
                ),
              ],
            ),
          ],
        ),
        isThreeLine: true,
      ),
    );
  }
  
  bool _isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year && date.month == now.month && date.day == now.day;
  }
  
  bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year && date1.month == date2.month && date1.day == date2.day;
  }
}