import 'package:cloud_firestore/cloud_firestore.dart';

class MedicationLog {
  final String id;
  final String scheduleId;
  final List<String> medicines;
  final int scheduledHour;
  final int scheduledMinute;
  final DateTime takenAt;

  MedicationLog({
    required this.id,
    required this.scheduleId,
    required this.medicines,
    required this.scheduledHour,
    required this.scheduledMinute,
    required this.takenAt,
  });

  // Factory constructor to create from Firestore data
  factory MedicationLog.fromFirestore(Map<String, dynamic> data, String docId) {
    return MedicationLog(
      id: docId,
      scheduleId: data['scheduleId'] ?? '',
      medicines: List<String>.from(data['medicines'] ?? []),
      scheduledHour: data['scheduledHour'] ?? 0,
      scheduledMinute: data['scheduledMinute'] ?? 0,
      takenAt: data['takenAt'] is DateTime
          ? data['takenAt']
          : (data['takenAt'] as Timestamp).toDate(),
    );
  }

  // Convert to a displayable string (for UI)
  String get medicinesDisplay => medicines.join(', ');

  // Convert to JSON for local storage if needed
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'scheduleId': scheduleId,
      'medicines': medicines,
      'scheduledHour': scheduledHour,
      'scheduledMinute': scheduledMinute,
      'takenAt': takenAt.toIso8601String(),
    };
  }

  // Create from JSON for local storage if needed
  factory MedicationLog.fromJson(Map<String, dynamic> json) {
    return MedicationLog(
      id: json['id'],
      scheduleId: json['scheduleId'],
      medicines: List<String>.from(json['medicines']),
      scheduledHour: json['scheduledHour'],
      scheduledMinute: json['scheduledMinute'],
      takenAt: DateTime.parse(json['takenAt']),
    );
  }

  get timestamp => null;
}