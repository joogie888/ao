import 'package:flutter/material.dart';

class Schedule {
  final String? id;
  final TimeOfDay time;
  final dynamic medicines;
  final bool? isEnabled;
  
  Schedule({
    this.id,
    required this.time,
    required this.medicines,
    this.isEnabled = true,
  });
  
  // Factory constructor to create Schedule from JSON
  factory Schedule.fromJson(Map<String, dynamic> json) {
    return Schedule(
      id: json['id'],
      time: TimeOfDay(
        hour: json['hour'] ?? 0, 
        minute: json['minute'] ?? 0
      ),
      medicines: json['medicines'] ?? '',
      isEnabled: json['isEnabled'] ?? true,
    );
  }
  
  // Convert Schedule to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'hour': time.hour,
      'minute': time.minute,
      'medicines': medicines,
      'isEnabled': isEnabled,
    };
  }
  
  // Create a copy of the Schedule with optional new values
  Schedule copyWith({
    String? id,
    TimeOfDay? time,
    dynamic medicines,
    bool? isEnabled,
  }) {
    return Schedule(
      id: id ?? this.id,
      time: time ?? this.time,
      medicines: medicines ?? this.medicines,
      isEnabled: isEnabled ?? this.isEnabled,
    );
  }
}